function VirTEX

% looking for VirTEX (Virtual Timeseries Experiment)?
%
% The light version (VirTEX Lite) is called delayandsum.m (in this directory)
% In includes Doppler due to platform motion.
% Doppler due to oceanographic effects is in prep.
%
% The heavy version is being cleaned up and will be distributed later ...
